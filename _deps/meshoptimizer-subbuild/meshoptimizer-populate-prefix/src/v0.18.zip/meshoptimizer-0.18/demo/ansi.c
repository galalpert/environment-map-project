/* This file makes sure the library can be used by C89 code */
#include "../src/meshoptimizer.h"
