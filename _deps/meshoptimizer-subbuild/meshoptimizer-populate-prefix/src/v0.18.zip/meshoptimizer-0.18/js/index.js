const MeshoptEncoder = require('./meshopt_encoder.js');
const MeshoptDecoder = require('./meshopt_decoder.js');

module.exports = {MeshoptEncoder, MeshoptDecoder};
